import "./App.css";
import { Card } from "./components/Card";

const data = [
  {
    title: "Pen",
    price: "$20",
    color: "white",
    date: new Date(2022, 7, 5),
  },
  {
    title: "Paper",
    price: '$10',
    color: "azur",
    date: new Date(2007, 3, 14),
  },
  {
    title: "Apple",
    price: '$50',
    color: "red",
    date: new Date(2015, 7, 24),
  },
  {
    title: "Book",
    price: '$35',
    color: "black",
    date: new Date(2018, 7, 24),
  },
];

export function App() {
  return (
    <div className="App">
      {data.map((el, i) => {
        return (
          <Card
            key={i}
            title={el.title}
            price={el.price}
            color={el.color}
            date={el.date}
          />
        );
      })}
    </div>
  );
}

