export function Card({ title, price, color, date }) {
  const realYear = new Date().getFullYear();
  const dataYear = date.getFullYear();

  return (
    <div>
      {realYear == dataYear ? (
        <div className="card">
          <div>{title}</div>
          <div>{price}</div>
          <div>{color}</div>
          <div>{date.toLocaleDateString()}</div>
        </div>
      ) : (
        <div className="card">
          <div>{title}</div>
          <div>{price}</div>
          <div>{color}</div>
          <div>{`${realYear - dataYear} year ago`}</div>
        </div>
      )}
    </div>
  );
}
