import "./App.css";
import { Id } from "./components/Id";
import { Img } from "./components/Img";
import { Title } from "./components/Title";

function App() {
  const user = [
    {
      id: 1,
      img: "https://sportishka.com/uploads/posts/2022-08/1660089734_1-sportishka-com-p-khinata-iz-voleibola-sport-krasivo-foto-1.jpg",
      title: "Alisher",
    },
    {
      id: 2,
      img: "https://insidethemagic.net/wp-content/uploads/2022/03/amazing-spider-man-800x400.jpg",
      title: "Abai",
    },
    {
      id: 3,
      img: "https://assets-prd.ignimgs.com/2022/09/20/iron-man-ea-motive-1663686372718.jpg",
      title: "Dastan",
    },
  ];

  return (
    <div className="App">
      {user.map((el) => {
        return (
          <div>
            <Id id={el.id} />
            <Img img={el.img} />
            <Title title={el.title} />
          </div>
        );
      })}
      ;
    </div>
  );
}

export default App;
