export function Id(props) {
  return <div className="name">{props.id}</div>;
}
