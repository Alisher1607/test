export function Title(props) {
  return <p>{props.title}</p>;
}
