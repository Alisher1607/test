export function Img(props) {
  return <img src={props.img} alt="img" />;
}
